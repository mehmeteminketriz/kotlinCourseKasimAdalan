package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim.override_kullanimi

open class Memeli : Hayvan() {
    //super : Üst sınıfı temsil eder.(Hayvan)
    //this : Bulunduğu sınıfı temsil eder.(Memeli)
}