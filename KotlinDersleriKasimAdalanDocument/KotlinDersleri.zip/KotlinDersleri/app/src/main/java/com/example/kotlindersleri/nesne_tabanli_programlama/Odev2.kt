package com.example.kotlindersleri.nesne_tabanli_programlama

class Odev2 {
    fun soru1(km:Double) : Double {
        return 0.0
    }
}