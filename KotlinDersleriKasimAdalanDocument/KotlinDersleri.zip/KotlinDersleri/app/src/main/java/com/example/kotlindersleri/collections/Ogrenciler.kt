package com.example.kotlindersleri.collections

data class Ogrenciler(var no:Int,var ad:String,var sinif:String) {
}