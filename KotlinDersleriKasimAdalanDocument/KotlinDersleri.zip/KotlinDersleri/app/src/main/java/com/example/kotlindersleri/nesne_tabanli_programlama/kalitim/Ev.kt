package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim

open class Ev(var pencereSayisi:Int) {//Superclass
}