package com.example.kotlindersleri.nesne_tabanli_programlama

fun main() {
    val o2 = Odev2()
    val sonuc1 = o2.soru1(0.0)
    println(sonuc1)
}