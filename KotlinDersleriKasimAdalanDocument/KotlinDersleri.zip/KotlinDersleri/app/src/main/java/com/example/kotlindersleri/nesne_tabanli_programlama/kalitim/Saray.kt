package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim

class Saray(var kuleSayisi:Int,pencereSayisi:Int) : Ev(pencereSayisi){
}