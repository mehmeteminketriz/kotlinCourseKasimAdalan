package com.example.kotlindersleri.nesne_tabanli_programlama.composition

data class Kategoriler(var kategori_id:Int,
                       var kategori_ad:String) {
}