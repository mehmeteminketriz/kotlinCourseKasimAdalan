package com.example.kotlindersleri.nesne_tabanli_programlama

enum class KonserveBoyut {
    KUCUK,ORTA,BUYUK
}