package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim.override_kullanimi

class Kopek : Memeli() {
    override fun sesCikar() {
        println("Hav Hav")
    }
}