package com.example.kotlindersleri.giris

fun main() {
   println("Merhaba Dünya Nasılsın")
}
