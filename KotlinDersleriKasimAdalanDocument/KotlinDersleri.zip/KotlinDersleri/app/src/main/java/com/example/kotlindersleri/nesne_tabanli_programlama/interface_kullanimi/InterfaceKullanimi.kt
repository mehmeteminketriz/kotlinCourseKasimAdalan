package com.example.kotlindersleri.nesne_tabanli_programlama.interface_kullanimi

fun main() {
    val a = ClassA()

    println(a.degisken)
    a.metod1()
    println(a.metod2())
}