package com.example.kotlindersleri.nesne_tabanli_programlama

fun main() {
    val a = ASinifi()

    //println(a.x)
    //a.metod()

    //Virtual Object - Sanal Nesne - İsimsiz nesne
    //println(ASinifi().x)
    //ASinifi().metod()

    println(ASinifi.x)
    ASinifi.metod()
}