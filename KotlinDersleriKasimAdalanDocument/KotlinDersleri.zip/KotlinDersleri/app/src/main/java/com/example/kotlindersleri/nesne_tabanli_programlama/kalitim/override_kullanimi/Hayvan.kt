package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim.override_kullanimi

open class Hayvan {
    open fun sesCikar(){
        println("Sesim yok")
    }
}