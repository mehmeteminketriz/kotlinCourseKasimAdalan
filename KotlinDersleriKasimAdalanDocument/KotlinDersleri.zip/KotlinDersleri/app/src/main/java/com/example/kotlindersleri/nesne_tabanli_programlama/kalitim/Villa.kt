package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim

class Villa(var garajVarmi:Boolean,pencereSayisi:Int) : Ev(pencereSayisi) {
}