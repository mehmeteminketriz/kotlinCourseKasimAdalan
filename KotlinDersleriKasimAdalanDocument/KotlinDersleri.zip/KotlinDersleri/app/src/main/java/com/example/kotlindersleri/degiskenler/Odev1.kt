package com.example.kotlindersleri.degiskenler

fun main() {
    val ilce : String = "Kadıköy"
    println("İlçe : $ilce")
}