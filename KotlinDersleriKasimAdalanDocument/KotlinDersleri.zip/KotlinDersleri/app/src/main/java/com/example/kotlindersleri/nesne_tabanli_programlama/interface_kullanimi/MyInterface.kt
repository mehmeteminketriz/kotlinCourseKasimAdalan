package com.example.kotlindersleri.nesne_tabanli_programlama.interface_kullanimi

interface MyInterface {
    val degisken:Int

    fun metod1()

    fun metod2():String
}