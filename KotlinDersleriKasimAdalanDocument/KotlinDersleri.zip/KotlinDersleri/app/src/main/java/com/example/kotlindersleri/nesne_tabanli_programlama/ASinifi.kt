package com.example.kotlindersleri.nesne_tabanli_programlama

class ASinifi {
    companion object {
        var x = 10

        fun metod(){
            println("Metod çalıştı")
        }
    }
}