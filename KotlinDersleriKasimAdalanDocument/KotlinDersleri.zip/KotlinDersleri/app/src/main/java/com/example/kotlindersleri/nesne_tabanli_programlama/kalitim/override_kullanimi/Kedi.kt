package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim.override_kullanimi

class Kedi : Memeli() {
    override fun sesCikar() {
        println("Miyav Miyav")
    }
}