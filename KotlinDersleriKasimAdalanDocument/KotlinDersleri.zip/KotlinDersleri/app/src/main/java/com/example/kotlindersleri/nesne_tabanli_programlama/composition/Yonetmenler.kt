package com.example.kotlindersleri.nesne_tabanli_programlama.composition

data class Yonetmenler(var yonetmen_id:Int,
                       var yonetmen_ad:String) {
}